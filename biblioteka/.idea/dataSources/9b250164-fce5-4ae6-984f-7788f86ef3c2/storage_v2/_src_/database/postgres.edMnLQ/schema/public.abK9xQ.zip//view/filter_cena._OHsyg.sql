create view filter_cena(ime_ekskurzija, cena, ime_grad) as
SELECT ekskurzija.ime_ekskurzija,
       ekskurzija.cena,
       grad.ime_grad
FROM (ekskurzija
         JOIN grad ON ((grad.id_grad = ekskurzija.id_grad)))
WHERE (ekskurzija.cena > (10)::double precision);

alter table filter_cena
    owner to postgres;

