create view vkupno_hotel(embg, ime, prezime, vkupno_hotel) as
SELECT DISTINCT klient.embg,
                klient.ime,
                klient.prezime,
                ((((rez.datum_do)::date - (rez.datum_od)::date))::double precision * cena.vrednost) AS vkupno_hotel
FROM ((((((rezervacija rez
    JOIN klient ON ((klient.embg = rez.embg)))
    JOIN soba s ON ((s.id_soba = rez.soba)))
    JOIN hotel ON ((hotel.id_hotel = s.id_hotel)))
    JOIN cena ON ((cena.id_soba = s.id_soba)))
    JOIN posetuvanje_ekskurzija pe ON ((pe.embg = klient.embg)))
         JOIN ekskurzija eks ON ((pe.id_ekskurzija = eks.id_ekskurzija)));

alter table vkupno_hotel
    owner to postgres;

