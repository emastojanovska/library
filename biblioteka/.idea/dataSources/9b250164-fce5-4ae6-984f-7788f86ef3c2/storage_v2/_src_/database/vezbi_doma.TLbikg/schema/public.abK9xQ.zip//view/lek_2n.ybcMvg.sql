create view lek_2n(id_lek, ime_lek, atc, ime, prezime, id_pacient, datum_prodazba) as
SELECT l.id_lek,
       l.ime AS ime_lek,
       l.atc,
       p.ime,
       p.prezime,
       p.id_pacient,
       s.datum_prodazba
FROM ((((apteki.pacienti p
    JOIN apteki.recepti r ON ((r.id_pacient = p.id_pacient)))
    JOIN apteki.prodazba pro ON ((pro.id_recept = r.id_recept)))
    JOIN apteki.smetki s ON ((s.id_smetka = pro.id_smetka)))
         JOIN apteki.lekovi l ON ((l.id_lek = pro.id_lek)));

alter table lek_2n
    owner to postgres;

