create view filter_ime(ime_ekskurzija, cena, ime_grad) as
SELECT ekskurzija.ime_ekskurzija,
       ekskurzija.cena,
       grad.ime_grad
FROM (ekskurzija
         JOIN grad ON ((grad.id_grad = ekskurzija.id_grad)))
WHERE ((ekskurzija.ime_ekskurzija)::text ~~* 'нуркање'::text);

alter table filter_ime
    owner to postgres;

