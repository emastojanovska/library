create view adrenalisnka_ekskurzija_view
            (id_ekskurzija, ime_ekskurzija, cena, vremetraenje, oprema, ime_grad, ime_drzava) as
SELECT eks.id_ekskurzija,
       eks.ime_ekskurzija,
       eks.cena,
       adrenalinska_ekskurzija.vremetraenje,
       adrenalinska_ekskurzija.oprema,
       g.ime_grad,
       g.ime_drzava
FROM ((ekskurzija eks
    JOIN adrenalinska_ekskurzija ON ((eks.id_ekskurzija = adrenalinska_ekskurzija.id_ekskurzija)))
         JOIN grad g ON ((eks.id_grad = g.id_grad)));

alter table adrenalisnka_ekskurzija_view
    owner to postgres;

