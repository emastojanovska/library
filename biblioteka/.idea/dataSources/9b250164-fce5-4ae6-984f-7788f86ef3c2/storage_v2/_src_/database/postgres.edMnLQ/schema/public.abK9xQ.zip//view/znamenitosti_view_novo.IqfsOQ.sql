create view znamenitosti_view_novo (id, id_ekskurzija, ime_ekskurzija, cena, znamenitost, ime_grad, ime_drzava) as
SELECT ((z.id_ekskurzija || ' '::text) || (z.znamenitost)::text) AS id,
       eks.id_ekskurzija,
       eks.ime_ekskurzija,
       eks.cena,
       z.znamenitost,
       g.ime_grad,
       g.ime_drzava
FROM (((ekskurzija eks
    JOIN ekskurzija_poseta ep ON ((eks.id_ekskurzija = ep.id_ekskurzija)))
    JOIN znamenitost z ON ((eks.id_ekskurzija = z.id_ekskurzija)))
         JOIN grad g ON ((eks.id_grad = g.id_grad)));

alter table znamenitosti_view_novo
    owner to postgres;

