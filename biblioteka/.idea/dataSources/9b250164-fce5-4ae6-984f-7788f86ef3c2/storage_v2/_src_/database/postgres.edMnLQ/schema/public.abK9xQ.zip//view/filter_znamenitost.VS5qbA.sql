create view filter_znamenitost(ime_grad, ime_ekskurzija, znamenitost) as
SELECT grad.ime_grad,
       eks.ime_ekskurzija,
       z.znamenitost
FROM (((ekskurzija eks
    JOIN grad ON ((eks.id_grad = grad.id_grad)))
    JOIN ekskurzija_poseta ep ON ((ep.id_ekskurzija = eks.id_ekskurzija)))
         JOIN znamenitost z ON ((ep.id_ekskurzija = z.id_ekskurzija)))
WHERE ((z.znamenitost)::text ~~* '%гробница%'::text);

alter table filter_znamenitost
    owner to postgres;

