create view filter_vremetraenje(ime_ekskurzija, cena, ime_grad, vremetraenje) as
SELECT ekskurzija.ime_ekskurzija,
       ekskurzija.cena,
       grad.ime_grad,
       ae.vremetraenje
FROM ((ekskurzija
    JOIN grad ON ((grad.id_grad = ekskurzija.id_grad)))
         JOIN adrenalinska_ekskurzija ae ON ((ae.id_ekskurzija = ekskurzija.id_ekskurzija)))
WHERE (ae.vremetraenje > 10);

alter table filter_vremetraenje
    owner to postgres;

