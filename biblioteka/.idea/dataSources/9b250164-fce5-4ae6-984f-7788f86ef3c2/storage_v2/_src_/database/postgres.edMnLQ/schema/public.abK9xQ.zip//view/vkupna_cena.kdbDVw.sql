create view vkupna_cena(embg, ime, prezime, vkupno_hotel, vkupno_ekskurzii, vkupna_cena) as
SELECT vh.embg,
       vh.ime,
       vh.prezime,
       vh.vkupno_hotel,
       ve.vkupno_ekskurzii,
       (vh.vkupno_hotel + ve.vkupno_ekskurzii) AS vkupna_cena
FROM (vkupno_ekskurzii ve
         LEFT JOIN vkupno_hotel vh ON ((ve.embg = vh.embg)));

alter table vkupna_cena
    owner to postgres;

