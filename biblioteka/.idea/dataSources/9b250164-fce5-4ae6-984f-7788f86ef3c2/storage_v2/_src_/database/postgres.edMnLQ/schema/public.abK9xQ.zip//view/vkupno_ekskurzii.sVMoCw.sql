create view vkupno_ekskurzii(embg, vkupno_ekskurzii) as
SELECT pe.embg,
       sum(eks.cena) AS vkupno_ekskurzii
FROM (posetuvanje_ekskurzija pe
         JOIN ekskurzija eks ON ((pe.id_ekskurzija = eks.id_ekskurzija)))
GROUP BY pe.embg;

alter table vkupno_ekskurzii
    owner to postgres;

