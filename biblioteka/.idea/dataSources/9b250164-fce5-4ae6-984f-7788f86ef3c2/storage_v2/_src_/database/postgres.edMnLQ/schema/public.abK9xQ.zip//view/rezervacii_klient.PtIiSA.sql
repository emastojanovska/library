create view rezervacii_klient(embg, ime, prezime, tip_soba, denovi, ime_hotel, ime_grad) as
SELECT klient.embg,
       klient.ime,
       klient.prezime,
       s.tip_soba,
       ((rez.datum_do)::date - (rez.datum_od)::date) AS denovi,
       hotel.ime_hotel,
       grad.ime_grad
FROM ((((rezervacija rez
    JOIN klient ON ((klient.embg = rez.embg)))
    JOIN soba s ON ((s.id_soba = rez.soba)))
    JOIN hotel ON ((hotel.id_hotel = s.id_hotel)))
         JOIN grad ON ((grad.id_grad = hotel.id_grad)))
WHERE (date_part('year'::text, rez.datum_od) = date_part('year'::text, now()));

alter table rezervacii_klient
    owner to postgres;

