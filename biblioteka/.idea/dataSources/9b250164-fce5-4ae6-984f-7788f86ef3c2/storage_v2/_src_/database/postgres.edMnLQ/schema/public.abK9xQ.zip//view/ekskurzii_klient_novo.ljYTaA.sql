create view ekskurzii_klient_novo(id, ime, prezime, embg, ime_ekskurzija, ime_grad, ime_drzava) as
SELECT (((klient.embg)::text || ' '::text) || (ekskurzija.ime_ekskurzija)::text) AS id,
       klient.ime,
       klient.prezime,
       pv.embg,
       ekskurzija.ime_ekskurzija,
       grad.ime_grad,
       grad.ime_drzava
FROM (((posetuvanje_ekskurzija pv
    JOIN klient ON ((klient.embg = pv.embg)))
    JOIN ekskurzija ON ((ekskurzija.id_ekskurzija = pv.id_ekskurzija)))
         JOIN grad ON ((grad.id_grad = ekskurzija.id_grad)));

alter table ekskurzii_klient_novo
    owner to postgres;

